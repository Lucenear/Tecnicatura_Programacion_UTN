# Parcial 2 - Programación III (JPA)

## Descripción del Proyecto
Este proyecto es una aplicación Java de consola construida con Gradle y JPA (Hibernate) que implementa un sistema de gestión para un catálogo de productos. Utiliza el **Patrón Repositorio** para separar la lógica de acceso a la base de datos (H2) de la lógica de negocio.

La aplicación permite realizar operaciones de tipo ABM (Alta, Baja lógica y Modificación) para las entidades `Categoria` y `Producto`, además de ofrecer consultas personalizadas mediante JPQL (Java Persistence Query Language) para filtrar productos por su categoría.

## Requisitos previos
- Java Development Kit (JDK) 17 o superior.
- No es necesario instalar una base de datos externa, ya que utiliza H2 en modo archivo local (se auto-genera en la carpeta `data/`).

## Instrucciones para ejecutarlo
Para compilar y ejecutar el proyecto directamente desde la terminal, ubícate en el directorio raíz del proyecto y utiliza el wrapper de Gradle:

### En Linux / macOS:
```bash
./gradlew run
```

### En Windows:
```cmd
gradlew.bat run
```

Una vez ejecutado el comando, la aplicación construirá el proyecto y desplegará automáticamente el Menú Principal interactivo en la consola. Solo debes ingresar el número de la opción deseada para navegar por el sistema.
