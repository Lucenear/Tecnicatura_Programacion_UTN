package com.utn;

import com.utn.entities.Categoria;
import com.utn.entities.Producto;
import com.utn.repository.CategoriaRepository;
import com.utn.repository.ProductoRepository;
import com.utn.util.JPAUtil;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Main {
    static {
        java.util.logging.LogManager.getLogManager().reset();
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
    }

    private static final Scanner scanner = new Scanner(System.in);
    private static final CategoriaRepository categoriaRepo = new CategoriaRepository();
    private static final ProductoRepository productoRepo = new ProductoRepository();

    public static void main(String[] args) {
        boolean salir = false;
        while (!salir) {
            System.out.println("--- MENU PRINCIPAL ---");
            System.out.println("1. ABM de Categorias");
            System.out.println("2. ABM de Productos");
            System.out.println("3. Reportes");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opcion: ");
            
            String opcion = scanner.nextLine();
            
            switch (opcion) {
                case "1":
                    menuCategorias();
                    break;
                case "2":
                    menuProductos();
                    break;
                case "3":
                    menuReportes();
                    break;
                case "4":
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        }
        JPAUtil.shutdown();
    }

    private static void menuCategorias() {
        boolean volver = false;
        while (!volver) {
            System.out.println("--- ABM CATEGORIAS ---");
            System.out.println("1. Alta");
            System.out.println("2. Baja logica");
            System.out.println("3. Modificacion");
            System.out.println("4. Listado");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opcion: ");
            
            String opcion = scanner.nextLine();
            
            switch (opcion) {
                case "1":
                    altaCategoria();
                    break;
                case "2":
                    bajaCategoria();
                    break;
                case "3":
                    modificarCategoria();
                    break;
                case "4":
                    listarCategorias();
                    break;
                case "5":
                    volver = true;
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        }
    }

    private static void altaCategoria() {
        System.out.print("Ingrese nombre de la categoria: ");
        String nombre = scanner.nextLine();
        if (nombre.trim().isEmpty()) {
            System.out.println("Error: el nombre no puede estar vacio.");
            return;
        }
        
        System.out.print("Ingrese descripcion: ");
        String descripcion = scanner.nextLine();
        
        Categoria cat = Categoria.builder()
                .nombre(nombre)
                .descripcion(descripcion)
                .build();
                
        cat = categoriaRepo.guardar(cat);
        System.out.println("Categoria guardada exitosamente con ID: " + cat.getId());
    }

    private static void bajaCategoria() {
        System.out.print("Ingrese el ID de la categoria a dar de baja: ");
        try {
            Long id = Long.parseLong(scanner.nextLine());
            boolean exito = categoriaRepo.eliminarLogico(id);
            if (exito) {
                System.out.println("Categoria dada de baja exitosamente.");
            } else {
                System.out.println("Error: No se encontro categoria activa con ese ID.");
            }
        } catch (NumberFormatException e) {
            System.out.println("ID invalido.");
        }
    }

    private static void modificarCategoria() {
        if (!listarCategorias()) {
            return;
        }
        System.out.print("Ingrese el ID de la categoria a modificar: ");
        try {
            Long id = Long.parseLong(scanner.nextLine());
            Optional<Categoria> opt = categoriaRepo.buscarPorId(id);
            if (opt.isPresent() && !opt.get().isEliminado()) {
                Categoria cat = opt.get();
                System.out.println("Valores actuales - Nombre: " + cat.getNombre() + ", Descripcion: " + cat.getDescripcion());
                
                System.out.print("Nuevo nombre (dejar en blanco para mantener actual): ");
                String nombre = scanner.nextLine();
                if (!nombre.trim().isEmpty()) {
                    cat.setNombre(nombre);
                }
                
                System.out.print("Nueva descripcion (dejar en blanco para mantener actual): ");
                String descripcion = scanner.nextLine();
                if (!descripcion.trim().isEmpty()) {
                    cat.setDescripcion(descripcion);
                }
                
                categoriaRepo.guardar(cat);
                System.out.println("Categoria modificada exitosamente.");
            } else {
                System.out.println("Error: Categoria no encontrada o dada de baja.");
            }
        } catch (NumberFormatException e) {
            System.out.println("ID invalido.");
        }
    }

    private static boolean listarCategorias() {
        List<Categoria> activas = categoriaRepo.listarActivos();
        if (activas.isEmpty()) {
            System.out.println("No hay categorias activas.");
            return false;
        }
        System.out.println("Categorias activas:");
        for (Categoria c : activas) {
            System.out.println("ID: " + c.getId() + " | Nombre: " + c.getNombre() + " | Descripcion: " + c.getDescripcion());
        }
        return true;
    }

    private static void menuProductos() {
        boolean volver = false;
        while (!volver) {
            System.out.println("--- ABM PRODUCTOS ---");
            System.out.println("1. Alta");
            System.out.println("2. Baja logica");
            System.out.println("3. Modificacion");
            System.out.println("4. Listado");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opcion: ");
            
            String opcion = scanner.nextLine();
            
            switch (opcion) {
                case "1":
                    altaProducto();
                    break;
                case "2":
                    bajaProducto();
                    break;
                case "3":
                    modificarProducto();
                    break;
                case "4":
                    listarProductos();
                    break;
                case "5":
                    volver = true;
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        }
    }

    private static void altaProducto() {
        List<Categoria> activas = categoriaRepo.listarActivos();
        if (activas.isEmpty()) {
            System.out.println("No hay categorias activas. Debe crear una categoria primero.");
            return;
        }
        
        System.out.println("Categorias disponibles:");
        for (Categoria c : activas) {
            System.out.println("ID: " + c.getId() + " - " + c.getNombre());
        }
        
        System.out.print("Ingrese ID de la categoria para el producto: ");
        try {
            Long catId = Long.parseLong(scanner.nextLine());
            Optional<Categoria> optCat = categoriaRepo.buscarPorId(catId);
            
            if (!optCat.isPresent() || optCat.get().isEliminado()) {
                System.out.println("Categoria invalida.");
                return;
            }
            
            System.out.print("Nombre del producto: ");
            String nombre = scanner.nextLine();
            
            System.out.print("Descripcion del producto: ");
            String descripcion = scanner.nextLine();
            
            System.out.print("Precio (mayor a 0): ");
            double precio = Double.parseDouble(scanner.nextLine());
            if (precio <= 0) {
                System.out.println("Error: el precio debe ser mayor a 0.");
                return;
            }
            
            System.out.print("Stock (mayor o igual a 0): ");
            int stock = Integer.parseInt(scanner.nextLine());
            if (stock < 0) {
                System.out.println("Error: el stock no puede ser negativo.");
                return;
            }
            
            Producto prod = Producto.builder()
                    .nombre(nombre)
                    .descripcion(descripcion)
                    .precio(precio)
                    .stock(stock)
                    .categoria(optCat.get())
                    .build();
                    
            prod = productoRepo.guardar(prod);
            System.out.println("Producto creado exitosamente con ID: " + prod.getId());
            
        } catch (NumberFormatException e) {
            System.out.println("Entrada invalida. Cancelando operacion.");
        }
    }

    private static void bajaProducto() {
        System.out.print("Ingrese el ID del producto a dar de baja: ");
        try {
            Long id = Long.parseLong(scanner.nextLine());
            Optional<Producto> opt = productoRepo.buscarPorId(id);
            if (opt.isPresent() && !opt.get().isEliminado()) {
                productoRepo.eliminarLogico(id);
                System.out.println("Producto " + opt.get().getNombre() + " dado de baja exitosamente.");
            } else {
                System.out.println("Error: Producto no encontrado o ya dado de baja.");
            }
        } catch (NumberFormatException e) {
            System.out.println("ID invalido.");
        }
    }

    private static void modificarProducto() {
        if (!listarProductos()) {
            return;
        }
        System.out.print("Ingrese el ID del producto a modificar: ");
        try {
            Long id = Long.parseLong(scanner.nextLine());
            Optional<Producto> opt = productoRepo.buscarPorId(id);
            if (opt.isPresent() && !opt.get().isEliminado()) {
                Producto prod = opt.get();
                System.out.println("Valores actuales:");
                System.out.println("Nombre: " + prod.getNombre());
                System.out.println("Precio: " + prod.getPrecio());
                System.out.println("Stock: " + prod.getStock());
                
                System.out.print("Nuevo nombre (dejar en blanco para mantener actual): ");
                String nombre = scanner.nextLine();
                if (!nombre.trim().isEmpty()) {
                    prod.setNombre(nombre);
                }
                
                System.out.print("Nuevo precio (dejar en blanco para mantener actual): ");
                String precioStr = scanner.nextLine();
                if (!precioStr.trim().isEmpty()) {
                    double precio = Double.parseDouble(precioStr);
                    if (precio <= 0) {
                        System.out.println("Error: el precio debe ser mayor a 0.");
                        return;
                    }
                    prod.setPrecio(precio);
                }
                
                System.out.print("Nuevo stock (dejar en blanco para mantener actual): ");
                String stockStr = scanner.nextLine();
                if (!stockStr.trim().isEmpty()) {
                    int stock = Integer.parseInt(stockStr);
                    if (stock < 0) {
                        System.out.println("Error: el stock no puede ser negativo.");
                        return;
                    }
                    prod.setStock(stock);
                }
                
                productoRepo.guardar(prod);
                System.out.println("Producto modificado exitosamente.");
            } else {
                System.out.println("Error: Producto no encontrado o dado de baja.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Entrada invalida. Cancelando operacion.");
        }
    }

    private static boolean listarProductos() {
        List<Producto> activos = productoRepo.listarActivos();
        if (activos.isEmpty()) {
            System.out.println("No hay productos activos.");
            return false;
        }
        System.out.println("Productos activos:");
        for (Producto p : activos) {
            String catName = (p.getCategoria() != null) ? p.getCategoria().getNombre() : "Sin categoria";
            System.out.println("ID: " + p.getId() + " | Nombre: " + p.getNombre() + " | Precio: " + p.getPrecio() + " | Stock: " + p.getStock() + " | Categoria: " + catName);
        }
        return true;
    }

    private static void menuReportes() {
        boolean volver = false;
        while (!volver) {
            System.out.println("--- REPORTES ---");
            System.out.println("1. Productos por categoria");
            System.out.println("2. Volver");
            System.out.print("Seleccione una opcion: ");
            
            String opcion = scanner.nextLine();
            
            switch (opcion) {
                case "1":
                    reporteProductosPorCategoria();
                    break;
                case "2":
                    volver = true;
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        }
    }

    private static void reporteProductosPorCategoria() {
        if (!listarCategorias()) {
            return;
        }
        System.out.print("Ingrese el ID de la categoria para buscar productos: ");
        try {
            Long id = Long.parseLong(scanner.nextLine());
            List<Producto> filtrados = productoRepo.buscarPorCategoria(id);
            if (filtrados.isEmpty()) {
                System.out.println("No hay productos activos en esa categoria.");
            } else {
                System.out.println("Productos de la categoria con ID " + id + ":");
                for (Producto p : filtrados) {
                    System.out.println("ID: " + p.getId() + " | Nombre: " + p.getNombre() + " | Precio: " + p.getPrecio() + " | Stock: " + p.getStock());
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("ID invalido.");
        }
    }
}
