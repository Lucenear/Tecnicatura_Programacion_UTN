package com.utn.entities;

public interface Calculable {
    Double calcularTotal();
}
