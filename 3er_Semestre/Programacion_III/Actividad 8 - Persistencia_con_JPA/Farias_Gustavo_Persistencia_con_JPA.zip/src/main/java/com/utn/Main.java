package com.utn;

import com.utn.entities.*;
import com.utn.enums.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("miUnidad");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            Categoria cat1 = Categoria.builder()
                    .nombre("Electronica")
                    .descripcion("Dispositivos electronicos")
                    .build();

            Categoria cat2 = Categoria.builder()
                    .nombre("Bazar")
                    .descripcion("Articulos para el hogar")
                    .build();

            Categoria cat3 = Categoria.builder()
                    .nombre("Indumentaria")
                    .descripcion("Ropa y calzado")
                    .build();

            Producto p1 = Producto.builder().nombre("Televisor").precio(120000.0).categoria(cat1).stock(15).build();
            Producto p2 = Producto.builder().nombre("Celular").precio(85000.0).categoria(cat1).stock(30).build();
            Producto p3 = Producto.builder().nombre("Notebook").precio(250000.0).categoria(cat1).stock(10).build();
            Producto p4 = Producto.builder().nombre("Auriculares").precio(15000.0).categoria(cat1).stock(50).build();
            Producto p5 = Producto.builder().nombre("Sarten").precio(8500.0).categoria(cat2).stock(25).build();
            Producto p6 = Producto.builder().nombre("Plato").precio(1200.0).categoria(cat2).stock(100).build();
            Producto p7 = Producto.builder().nombre("Vaso").precio(800.0).categoria(cat2).stock(120).build();
            Producto p8 = Producto.builder().nombre("Remera").precio(4500.0).categoria(cat3).stock(40).build();
            Producto p9 = Producto.builder().nombre("Pantalon").precio(9500.0).categoria(cat3).stock(20).build();
            Producto p10 = Producto.builder().nombre("Zapatillas").precio(35000.0).categoria(cat3).stock(15).build();

            cat1.getProductos().add(p1);
            cat1.getProductos().add(p2);
            cat1.getProductos().add(p3);
            cat1.getProductos().add(p4);
            
            cat2.getProductos().add(p5);
            cat2.getProductos().add(p6);
            cat2.getProductos().add(p7);
            
            cat3.getProductos().add(p8);
            cat3.getProductos().add(p9);
            cat3.getProductos().add(p10);

            em.persist(cat1);
            em.persist(cat2);
            em.persist(cat3);

            em.persist(p1);
            em.persist(p2);
            em.persist(p3);
            em.persist(p4);
            em.persist(p5);
            em.persist(p6);
            em.persist(p7);
            em.persist(p8);
            em.persist(p9);
            em.persist(p10);

            em.flush();

            Usuario u1 = Usuario.builder()
                    .nombre("Juan")
                    .apellido("Perez")
                    .mail("juan.perez@utn.com")
                    .celular("261123456")
                    .contrasena("juan123")
                    .rol(Rol.ADMIN)
                    .build();

            Usuario u2 = Usuario.builder()
                    .nombre("Maria")
                    .apellido("Gomez")
                    .mail("maria.gomez@utn.com")
                    .celular("261987654")
                    .contrasena("maria456")
                    .rol(Rol.USUARIO)
                    .build();

            Pedido pedido1 = Pedido.builder()
                    .fecha(LocalDate.now())
                    .estado(Estado.PENDIENTE)
                    .formaPago(FormaPago.EFECTIVO)
                    .build();
            pedido1.addDetallePedido(2, p1);
            pedido1.addDetallePedido(1, p2);
            u1.addPedido(pedido1);

            Pedido pedido2 = Pedido.builder()
                    .fecha(LocalDate.now().minusDays(1))
                    .estado(Estado.CONFIRMADO)
                    .formaPago(FormaPago.TARJETA)
                    .build();
            pedido2.addDetallePedido(1, p3);
            pedido2.addDetallePedido(4, p4);
            u1.addPedido(pedido2);

            Pedido pedido3 = Pedido.builder()
                    .fecha(LocalDate.now())
                    .estado(Estado.PENDIENTE)
                    .formaPago(FormaPago.TRANSFERENCIA)
                    .build();
            pedido3.addDetallePedido(3, p5);
            pedido3.addDetallePedido(6, p6);
            u2.addPedido(pedido3);

            em.persist(u1);
            em.persist(u2);

            em.getTransaction().commit();
            System.out.println("Entidades persistidas correctamente.");

            em.getTransaction().begin();
            Producto pActualizar1 = em.find(Producto.class, p1.getId());
            if (pActualizar1 != null) {
                pActualizar1.setPrecio(130000.0);
                pActualizar1.setStock(20);
                em.merge(pActualizar1);
            }

            Producto pActualizar2 = em.find(Producto.class, p8.getId());
            if (pActualizar2 != null) {
                pActualizar2.setPrecio(5000.0);
                pActualizar2.setStock(35);
                em.merge(pActualizar2);
            }
            em.getTransaction().commit();
            System.out.println("Productos actualizados correctamente.");

            Usuario uBuscadoId = em.find(Usuario.class, u1.getId());
            if (uBuscadoId != null) {
                System.out.println("Usuario encontrado por ID: " + uBuscadoId.getNombreCompleto());
            }

            try {
                Usuario uBuscadoMail = em.createQuery("SELECT u FROM Usuario u WHERE u.mail = :mail", Usuario.class)
                        .setParameter("mail", "maria.gomez@utn.com")
                        .setMaxResults(1)
                        .getSingleResult();
                System.out.println("Usuario encontrado por mail: " + uBuscadoMail.getNombreCompleto());
            } catch (Exception e) {
                System.out.println("Usuario no encontrado por mail o error en la consulta.");
            }

            em.getTransaction().begin();
            Producto pBorrar = em.find(Producto.class, p10.getId());
            if (pBorrar != null) {
                em.remove(pBorrar);
                System.out.println("Producto borrado correctamente.");
            }
            em.getTransaction().commit();

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            e.printStackTrace();
        } finally {

            em.close();
            emf.close();
        }
    }
}
