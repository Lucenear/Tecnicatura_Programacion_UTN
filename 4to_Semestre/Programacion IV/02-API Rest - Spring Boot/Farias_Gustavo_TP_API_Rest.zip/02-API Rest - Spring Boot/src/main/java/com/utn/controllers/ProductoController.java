package com.utn.controllers;

import com.utn.dtos.producto.ProductoCreate;
import com.utn.entities.Producto;
import com.utn.services.ProductoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @PostMapping
    public ResponseEntity<Producto> create(@RequestBody ProductoCreate dto) {
        return new ResponseEntity<>(productoService.create(dto), HttpStatus.CREATED);
    }
}
