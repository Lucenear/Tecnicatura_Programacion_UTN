package com.utn.controllers;

import com.utn.dtos.categoria.CategoriaCreate;
import com.utn.dtos.categoria.CategoriaEdit;
import com.utn.entities.Categoria;
import com.utn.services.CategoriaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/categorias")
public class CategoriaController {

    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @PostMapping
    public ResponseEntity<Categoria> create(@RequestBody CategoriaCreate dto) {
        return new ResponseEntity<>(categoriaService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Categoria> update(@PathVariable Long id, @RequestBody CategoriaEdit dto) {
        return ResponseEntity.ok(categoriaService.update(id, dto));
    }
}
