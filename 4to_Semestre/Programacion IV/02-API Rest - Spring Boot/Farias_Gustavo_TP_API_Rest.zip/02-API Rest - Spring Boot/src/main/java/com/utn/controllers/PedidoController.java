package com.utn.controllers;

import com.utn.dtos.detallePedido.DetallePedidoCreate;
import com.utn.dtos.pedido.PedidoDto;
import com.utn.entities.Pedido;
import com.utn.services.PedidoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    public static class PedidoCreateRequest {
        private Long usuarioId;
        private PedidoDto pedido;
        private List<DetallePedidoCreate> detalles;

        public Long getUsuarioId() { return usuarioId; }
        public void setUsuarioId(Long usuarioId) { this.usuarioId = usuarioId; }
        public PedidoDto getPedido() { return pedido; }
        public void setPedido(PedidoDto pedido) { this.pedido = pedido; }
        public List<DetallePedidoCreate> getDetalles() { return detalles; }
        public void setDetalles(List<DetallePedidoCreate> detalles) { this.detalles = detalles; }
    }

    @PostMapping
    public ResponseEntity<Pedido> create(@RequestBody PedidoCreateRequest request) {
        return new ResponseEntity<>(pedidoService.createFromDto(
                request.getUsuarioId(),
                request.getPedido(),
                request.getDetalles()), HttpStatus.CREATED);
    }
}
